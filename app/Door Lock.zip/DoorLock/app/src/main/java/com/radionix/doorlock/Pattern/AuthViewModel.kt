package com.radionix.doorlock.Pattern

import androidx.lifecycle.ViewModel

class AuthViewModel :ViewModel() {
}