package com.radionix.doorlock.product

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.Toast
import androidx.lifecycle.ViewModel
import com.radionix.doorlock.Pattern.AuthenticationActivity
import com.radionix.doorlock.helper.AppController

class ProductViewModel : ViewModel()  {


    var productName :String? = null


    fun isOkProduct(view : Context)
    {
        val appController  = AppController(view)
        if (appController.getIsOkProduct()) {
            Intent(view, AuthenticationActivity::class.java).also {
                view.startActivity(it)
                val activity = view as Activity
                activity.finish()
            }.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
    }

    fun scan(view: View)
    {
        Intent(view.context, ScannerActivity::class.java).also {
            view.context.startActivity(it)
        }
    }

    fun getCheck(view: View) {

        val appController = AppController(view.context)
        if(productName!!.contains("Rdx2702",false)){
            appController.putIsOkProduct(true)
            Intent(view.context, AuthenticationActivity::class.java).also {
                view.context.startActivity(it)
                val activity = view.context as Activity
                activity.finish()
            }.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }else{
            Toast.makeText(
                view.context, "Incorrect product ID...",
                Toast.LENGTH_SHORT
            ).show()
        }

    }
}
