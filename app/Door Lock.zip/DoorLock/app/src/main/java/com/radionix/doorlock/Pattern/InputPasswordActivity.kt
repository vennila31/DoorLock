package com.radionix.doorlock.Pattern

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.radionix.doorlock.R

class InputPasswordActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_input_password)
    }
}