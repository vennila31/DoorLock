package com.radionix.doorlock.Home

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Handler
import androidx.lifecycle.ViewModel
import com.radionix.doorlock.Pattern.AuthenticationActivity


class MainViewModel : ViewModel() {

    fun initialize(view : Context)
    {
        val handler = Handler()
        handler.postDelayed({
            val sharedPreferences: SharedPreferences = view.getSharedPreferences("PREFS", 0)
            val password = sharedPreferences.getString("password", "0")
            if (password == "0") {
                // Intent to navigate to Create Password Screen
                Intent(view, AuthenticationActivity::class.java).also {
                    view.startActivity(it)
                    val activity = view as Activity
                    activity.finish()
                }
            } else {
                // Intent to navigate to Input Password Screen
                Intent(view, AuthenticationActivity::class.java).also {
                    view.startActivity(it)
                    val activity = view as Activity
                    activity.finish()
                }
            }
        }, 2000)
    }

}