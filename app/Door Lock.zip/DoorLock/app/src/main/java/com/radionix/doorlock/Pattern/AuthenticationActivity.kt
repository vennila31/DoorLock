package com.radionix.doorlock.Pattern

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.radionix.doorlock.R
import com.radionix.doorlock.databinding.ActivityAuthenticationBinding

class AuthenticationActivity : AppCompatActivity() {

    private val viewModel: AuthViewModel by lazy {
        ViewModelProvider(this)[AuthViewModel::class.java]
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding : ActivityAuthenticationBinding =
            DataBindingUtil.setContentView(this,R.layout.activity_authentication)

        binding.lifecycleOwner = this
        binding.viewModel = viewModel
        binding.executePendingBindings()

    }
}